package com.capgemini.tcc.exception;

public class PatientException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public PatientException(String message) 
	{
		
		super(message);
	}
}
